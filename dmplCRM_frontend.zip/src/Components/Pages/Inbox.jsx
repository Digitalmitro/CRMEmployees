import React from 'react'

const Inbox = () => {
    return (
        <div>Inbox</div>
    )
}

export default Inbox